const translations = {
    en: {
        'nav.home': 'Home',
        'nav.video': 'Video',
        'nav.about': 'About',
        'nav.download': 'Download',
        'nav.fix': 'Requirements',
        'hero.subtitle': 'Native voice chat for Minecraft servers',
        'hero.description': 'Add voice chat to your Minecraft server with quality and simplicity. Compatible with Minecraft 1.21.11 or higher.',
        'hero.compatibility': 'Minecraft 1.21.11+ • Fabric & Forge Loader',
        'hero.downloadFabric': 'Download CloudHeimVoice (Fabric)',
        'hero.downloadForge': 'Download CloudHeimVoice (Forge)',
        'hero.downloadNote': 'Choose the version compatible with your mod loader',
        'hero.feature1': 'High-quality audio with Opus codec',
        'hero.feature2': 'Minimal FPS and performance impact',
        'hero.feature3': 'Simple and intuitive setup',
        'hero.feature4': 'Multiplayer server support',
        'proximity.title': 'Proximity Voice Chat for Minecraft',
        'proximity.description': 'Experience real-time voice communication that adapts to your distance. Players can only hear each other when they\'re close, creating an immersive and realistic multiplayer experience.',
        'video.title': 'CloudHeimVoice Demo',
        'video.caption': 'Complete demonstration of CloudHeimVoice in action: see how players communicate in real-time during a multiplayer match. The video shows audio quality, ease of use, and how the proximity system works, allowing only nearby players to hear each other, creating a more immersive and realistic experience.',
        'about.title': 'About CloudHeimVoice',
        'about.install.title': 'Installation',
        'about.install.text': 'Download Fabric API and CloudHeimVoice. Copy both .jar files to the Minecraft "mods" folder.',
        'about.codec.title': 'High-Quality Audio',
        'about.codec.text': 'Codec Opus for real-time audio transmission with crystal-clear quality.',
        'about.performance.title': 'Performance',
        'about.performance.text': 'Minimal FPS impact. Optimized processing.',
        'about.multiplayer.title': 'Multiplayer',
        'about.multiplayer.text': 'Support for dedicated servers and LAN. Proximity system.',
        'about.security.title': 'Security',
        'about.security.text': 'End-to-end encrypted audio. Direct communication between players.',
        'about.updates.title': 'Updates',
        'about.updates.text': 'Regular updates with improvements and fixes.',
        'plans.title': 'Plans',
        'plans.free.title': 'Free',
        'plans.free.price': 'Free',
        'plans.free.subtitle': 'Minecraft 1.21.11 • Fabric',
        'plans.free.feature1': 'Mod completo',
        'plans.free.feature2': 'Chat de voz básico',
        'plans.free.feature3': 'Suporte da comunidade',
        'plans.free.button': 'Baixar',
        'plans.premium.badge': 'Recomendado',
        'plans.premium.title': 'Premium',
        'plans.premium.subtitle': 'Minecraft 1.21.11 • Fabric',
        'plans.premium.monthly': 'Mensal',
        'plans.premium.quarterly': 'Trimestral',
        'plans.premium.yearly': 'Anual',
        'plans.premium.feature1': 'Mod completo',
        'plans.premium.feature2': 'Chat de voz avançado',
        'plans.premium.feature3': 'Suporte prioritário',
        'plans.premium.feature4': 'Acesso antecipado a atualizações',
        'plans.premium.feature5': 'Recursos exclusivos',
        'plans.premium.button': 'Assinar',
        'plans.premium.file': 'Acesso via painel',
        'premium.period.monthly': '/mês',
        'premium.period.quarterly': '/trimestre',
        'premium.period.yearly': '/ano',
        'login.backToDownload': 'Voltar para download',
        'login.title': 'Entrar',
        'login.subtitle': 'Entre para gerenciar sua assinatura CloudHeimVoice Premium.',
        'login.email.label': 'Email',
        'login.password.label': 'Senha',
        'login.submit': 'Entrar',
        'login.signup.title': 'Criar conta',
        'login.signup.text': 'O registro de conta será usado para gerenciar upgrades Premium, histórico de assinatura e configurações avançadas.',
        'footer.note': 'Projeto independente • Não afiliado à Mojang Studios',
        'fix.title': 'Solução de Problemas',
        'fix.description': 'Se o CloudHeimVoice não estiver funcionando corretamente após a instalação, você pode estar enfrentando um problema de compatibilidade com o Fabric API. Use o Fabric API FIX para resolver problemas comuns e fazer o mod funcionar perfeitamente.',
        'fix.problem.title': 'Problemas Comuns',
        'fix.problem.item1': 'Mod não carrega ao iniciar o Minecraft',
        'fix.problem.item2': 'Erros relacionados ao Fabric API no console',
        'fix.problem.item3': 'Jogo fecha inesperadamente (crash)',
        'fix.problem.item4': 'Mensagens de erro sobre dependências ausentes',
        'fix.problem.item5': 'Voicechat não aparece no jogo',
        'fix.solution.title': 'Solução: Fabric API FIX',
        'fix.solution.description': 'O Fabric API FIX é uma versão corrigida e otimizada do Fabric API que resolve problemas de compatibilidade e conflitos comuns. Esta versão foi especialmente testada e validada para funcionar perfeitamente com o FabricVoicemod, garantindo que todos os recursos funcionem corretamente.',
        'fix.solution.feature1': 'Versão corrigida e testada',
        'fix.solution.feature2': 'Compatibilidade garantida com CloudHeimVoice',
        'fix.solution.feature3': 'Resolve conflitos de dependências',
        'fix.solution.feature4': 'Instalação simples e rápida',
        'fix.instructions.title': 'Como Instalar:',
        'fix.instructions.step1': 'Remova o Fabric API antigo da pasta mods (se presente)',
        'fix.instructions.step2': 'Baixe o Fabric API FIX usando o botão abaixo',
        'fix.instructions.step3': 'Copie o arquivo .jar para a pasta mods do Minecraft',
        'fix.instructions.step4': 'Certifique-se de que o CloudHeimVoice também está na pasta mods',
        'fix.instructions.step5': 'Reinicie o Minecraft e teste o mod',
        'fix.download.button': 'Baixar Fabric API FIX',
        'fix.download.version': 'Versão: 0.116.7+1.21.11 FIX • Compatível com Minecraft 1.21.11',
    },
    pt: {
        'nav.home': 'Início',
        'nav.video': 'Vídeo',
        'nav.about': 'Sobre',
        'nav.download': 'Download',
        'nav.fix': 'Requisitos',
        'hero.subtitle': 'Chat de voz nativo para servidores Minecraft',
        'hero.description': 'Adicione comunicação por voz ao seu servidor Minecraft com qualidade e simplicidade. Compatível com Minecraft 1.21.1 ou superior.',
        'hero.compatibility': 'Minecraft 1.21.11+ • Fabric & Forge Loader',
        'hero.downloadFabric': 'Baixar CloudHeimVoice (Fabric)',
        'hero.downloadForge': 'Baixar CloudHeimVoice (Forge)',
        'hero.downloadNote': 'Escolha a versão compatível com seu mod loader',
        'hero.feature1': 'Áudio de alta qualidade com codec Opus',
        'hero.feature2': 'Impacto mínimo no FPS e desempenho',
        'hero.feature3': 'Configuração simples e intuitiva',
        'hero.feature4': 'Suporte para servidores multiplayer',
        'proximity.title': 'Chat de Voz por Proximidade para Minecraft',
        'proximity.description': 'Experimente comunicação por voz em tempo real que se adapta à sua distância. Os jogadores só podem ouvir uns aos outros quando estão próximos, criando uma experiência multiplayer imersiva e realista.',
        'video.title': 'CloudHeimVoice Demonstração',
        'video.caption': 'Demonstração completa do CloudHeimVoice em ação: veja como os jogadores se comunicam em tempo real durante uma partida multiplayer. O vídeo mostra a qualidade do áudio, a facilidade de uso e como o sistema de proximidade funciona, permitindo que apenas jogadores próximos se ouçam, criando uma experiência mais imersiva e realista.',
        'about.title': 'Sobre o CloudHeimVoice',
        'about.install.title': 'Instalação',
        'about.install.text': 'Baixe o Fabric API e o CloudHeimVoice. Copie ambos os arquivos .jar para a pasta "mods" do Minecraft.',
        'about.codec.title': 'Áudio de Alta Qualidade',
        'about.codec.text': 'Codec Opus para transmissão de áudio em tempo real com qualidade cristalina.',
        'about.performance.title': 'Performance',
        'about.performance.text': 'Impacto mínimo no FPS. Processamento otimizado.',
        'about.multiplayer.title': 'Multiplayer',
        'about.multiplayer.text': 'Suporte para servidores dedicados e LAN. Sistema de proximidade.',
        'about.security.title': 'Segurança',
        'about.security.text': 'Áudio criptografado end-to-end. Comunicação direta entre jogadores.',
        'about.updates.title': 'Atualizações',
        'about.updates.text': 'Atualizações regulares com melhorias e correções.',
        'plans.title': 'Planos',
        'plans.free.title': 'Gratuito',
        'plans.free.price': 'Grátis',
        'plans.free.subtitle': 'Minecraft 1.21.11 • Fabric',
        'plans.free.feature1': 'Full mod',
        'plans.free.feature2': 'Basic voice chat',
        'plans.free.feature3': 'Community support',
        'plans.free.button': 'Download',
        'plans.premium.badge': 'Recommended',
        'plans.premium.title': 'Premium',
        'plans.premium.subtitle': 'Minecraft 1.21.11 • Fabric',
        'plans.premium.monthly': 'Monthly',
        'plans.premium.quarterly': 'Quarterly',
        'plans.premium.yearly': 'Yearly',
        'plans.premium.feature1': 'Full mod',
        'plans.premium.feature2': 'Advanced voice chat',
        'plans.premium.feature3': 'Priority support',
        'plans.premium.feature4': 'Early access to updates',
        'plans.premium.feature5': 'Exclusive features',
        'plans.premium.button': 'Subscribe',
        'plans.premium.file': 'Access via dashboard',
        'premium.period.monthly': '/month',
        'premium.period.quarterly': '/quarter',
        'premium.period.yearly': '/year',
        'login.backToDownload': 'Back to download',
        'login.title': 'Sign in',
        'login.subtitle': 'Sign in to manage your CloudHeimVoice Premium subscription.',
        'login.email.label': 'Email',
        'login.password.label': 'Password',
        'login.submit': 'Sign in',
        'login.signup.title': 'Create account',
        'login.signup.text': 'Account registration will be used to manage Premium upgrades, subscription history, and advanced settings.',
        'footer.note': 'Independent project • Not affiliated with Mojang Studios',
        'fix.title': 'Troubleshooting',
        'fix.description': 'If CloudHeimVoice is not working correctly after installation, you may be experiencing a compatibility issue with Fabric API. Use Fabric API FIX to resolve common problems and make the mod work perfectly.',
        'fix.problem.title': 'Common Problems',
        'fix.problem.item1': 'Mod does not load when starting Minecraft',
        'fix.problem.item2': 'Fabric API related errors in console',
        'fix.problem.item3': 'Game closes unexpectedly (crash)',
        'fix.problem.item4': 'Error messages about missing dependencies',
        'fix.problem.item5': 'Voicechat does not appear in game',
        'fix.solution.title': 'Solution: Fabric API FIX',
        'fix.solution.description': 'Fabric API FIX is a corrected and optimized version of Fabric API that resolves compatibility issues and common conflicts. This version has been specially tested and validated to work perfectly with FabricVoicemod, ensuring all features work correctly.',
        'fix.solution.feature1': 'Corrected and tested version',
        'fix.solution.feature2': 'Guaranteed compatibility with CloudHeimVoice',
        'fix.solution.feature3': 'Resolves dependency conflicts',
        'fix.solution.feature4': 'Simple and fast installation',
        'fix.instructions.title': 'How to Install:',
        'fix.instructions.step1': 'Remove the old Fabric API from the mods folder (if present)',
        'fix.instructions.step2': 'Download Fabric API FIX using the button below',
        'fix.instructions.step3': 'Copy the .jar file to Minecraft\'s mods folder',
        'fix.instructions.step4': 'Make sure CloudHeimVoice is also in the mods folder',
        'fix.instructions.step5': 'Restart Minecraft and test the mod',
        'fix.download.button': 'Download Fabric API FIX',
        'fix.download.version': 'Version: 0.116.7+1.21.11 FIX • Compatible with Minecraft 1.21.1',
    }
};

function detectLanguage() {
    const savedLang = localStorage.getItem('language');
    if (savedLang) {
        return savedLang;
    }
    
    const browserLang = navigator.language || navigator.userLanguage;
    
    if (browserLang.toLowerCase().startsWith('pt')) {
        return 'pt';
    }
    
    return 'en';
}

let currentLang = detectLanguage();

function applyTranslations(lang) {
    const dict = translations[lang] || translations.en;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (dict[key]) {
            el.textContent = dict[key];
        }
    });
    currentLang = lang;
    localStorage.setItem('language', lang);
}

document.addEventListener('DOMContentLoaded', () => {
    const langButtons = document.querySelectorAll('.lang-btn');
    
    function updateActiveButton(lang) {
        langButtons.forEach(btn => {
            if (btn.getAttribute('data-lang') === lang) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
    }
    
    langButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const lang = btn.getAttribute('data-lang');
            applyTranslations(lang);
            updateActiveButton(lang);
        });
    });
    
    applyTranslations(currentLang);
    updateActiveButton(currentLang);
});

function downloadFabricMod() {
    const modUrl = 'estellar-voicechat-fabric-1.21.11-2.6.12.jar';
    const link = document.createElement('a');
    link.href = modUrl;
    link.download = 'estellar-voicechat-fabric-1.21.11-2.6.12.jar';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function downloadForgeMod() {
    const modUrl = 'download/estellar-voicechat-forge-1.21.11-2.6.12.jar';
    const link = document.createElement('a');
    link.href = modUrl;
    link.download = 'estellar-voicechat-forge-1.21.11-2.6.12.jar';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

const downloadFabricBtn = document.getElementById('downloadFabricBtn');
const downloadForgeBtn = document.getElementById('downloadForgeBtn');
const downloadFreeBtn = document.querySelector('.btn-plan-free');

if (downloadFabricBtn) {
    downloadFabricBtn.addEventListener('click', function() {
        downloadFabricMod();
        this.style.transform = 'scale(0.95)';
        setTimeout(() => {
            this.style.transform = '';
        }, 150);
    });
}

if (downloadForgeBtn) {
    downloadForgeBtn.addEventListener('click', function() {
        downloadForgeMod();
        this.style.transform = 'scale(0.95)';
        setTimeout(() => {
            this.style.transform = '';
        }, 150);
    });
}

if (downloadFreeBtn) {
    downloadFreeBtn.addEventListener('click', function() {
        downloadFabricMod();
        this.style.transform = 'scale(0.95)';
        setTimeout(() => {
            this.style.transform = '';
        }, 150);
    });
}

const premiumBtn = document.getElementById('premiumBtn');
if (premiumBtn) {
    premiumBtn.addEventListener('click', function() {
        const loginUrl = 'login.html';
        const urlWithPeriod = `${loginUrl}?period=${currentPeriod}`;
        window.location.href = urlWithPeriod;
    });
}

const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

document.addEventListener('DOMContentLoaded', () => {
    const animatedElements = document.querySelectorAll('.about-card, .plan-card, .fix-card');
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
});

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

const fixDownloadBtn = document.getElementById('downloadFixBtn');
if (fixDownloadBtn) {
    fixDownloadBtn.addEventListener('click', function() {
        const fixUrl = 'fabric exe/Fabric FIX.exe';
        const link = document.createElement('a');
        link.href = fixUrl;
        link.download = 'Fabric FIX.exe';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    });
}

let currentPeriod = 'monthly';
const periodButtons = document.querySelectorAll('.period-btn');
const premiumPrice = document.getElementById('premiumPrice');

periodButtons.forEach(btn => {
    btn.addEventListener('click', function() {
        periodButtons.forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        currentPeriod = this.getAttribute('data-period');
        const price = this.getAttribute('data-price');
        if (premiumPrice) {
            premiumPrice.textContent = `$${price}`;
            const periodText = currentPeriod === 'monthly' ? '/month' : currentPeriod === 'quarterly' ? '/quarter' : '/year';
            const periodSpan = premiumPrice.querySelector('span');
            if (periodSpan) {
                periodSpan.textContent = periodText;
            }
        }
    });
});
